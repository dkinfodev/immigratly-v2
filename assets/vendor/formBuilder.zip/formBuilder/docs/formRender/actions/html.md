# `html` action

To grab the rendered form's HTML complete with user entered data

## Usage
<pre><code class="js">
const html = $('#render-container').formRender('html'); // HTML string
</code></pre>

### In Action
<p data-height="300" data-theme-id="22927" data-slug-hash="wWvyaM" data-default-tab="result" data-user="kevinchappell" data-embed-version="2" class="codepen"></p>
