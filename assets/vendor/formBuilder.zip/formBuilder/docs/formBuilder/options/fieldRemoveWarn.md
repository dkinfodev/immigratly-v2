# fieldRemoveWarn
`fieldRemoveWarn` warn user's if before the remove a field from the stage.

## Usage
```javascript
var options = {
      fieldRemoveWarn: true // defaults to false
    };
$(container).formBuilder(options);
```


## See it in Action
<p data-height="525" data-theme-id="22927" data-embed-version="2" data-slug-hash="aNyGdq" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
