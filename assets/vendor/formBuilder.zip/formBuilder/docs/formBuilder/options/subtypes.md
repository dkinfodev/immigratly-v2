# subtypes
Define new types to be used with field base types such as button and input.

## Usage
```javascript
var options = {
    subtypes: {
        text: ['datetime-local']
    }
};
$(container).formBuilder(options);
```
## See it in Action
<p data-height="525" data-theme-id="22927" data-embed-version="2" data-slug-hash="YNgvLq" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
