@extends('emails.mail-master')

@section('content')
<div style="padding:20px">
    <?php echo $mail_message ?>
</div>
@endsection